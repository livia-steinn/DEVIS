//////////////////////////////// DESAFIO 3 ////////////////////////////////

// • Álcool ou Gasolina? (Matemática + Lógica)
// • Objetivo: Praticar lógica aplicada ao dia a dia.
// • Enunciado: Dizem que só compensa abastecer com Álcool se o
// preço dele for menor que 70% do preço da Gasolina. Peça o preço
// do litro de cada um. O programa deve calcular: `precoAlcool /
// precoGasolina`. Se o resultado for menor que 0.7, mostre
// "Abasteça com ÁLCOOL". Caso contrário, mostre "Abasteça com
// GASOLINA".


const entrada = require('readline-sync');

console.log("---SISTEMA DE ANALISE DE ESCOLHA DO COMBUSTIVEL---");

const precoAlcool = entrada.questionFloat("Preco do litro do Alcool: ");
const precoGasolina = entrada.questionFloat("Preco do litro da Gasolina: ");
const diferenca = precoAlcool / precoGasolina;

if (diferenca < 0.7) {
    console.log(`\n Abasteca com ALCOOL`)
} else {
    console.log(`\nAbasteca com GASOLINA`)
}

