//////////////////////////////// DESAFIO 2 ////////////////////////////////

// • O "Mão de Vaca" (Cálculo com Decisão)
// • Objetivo:** Praticar cálculos e `if/else`.
// • Enunciado: Um restaurante está dando 10% de desconto para
// contas acima de R$ 100,00. Peça o valor total da conta. Se for
// acima de 100, mostre o valor com desconto. Se for abaixo, mostre
// o valor normal.


const entrada = require('readline-sync');

console.log("---SISTEMA DE DESCONTO---");

const valorConta = entrada.questionFloat("Valor total da conta: ");

if (valorConta > 100) {
    const desconto = valorConta * 0.9
    console.log(`\n Você ganhou um desconto de 10%. O valor a ser pago é de ${desconto} reais.`);
} else {
    console.log(`\n O valor a ser pago é de ${valorConta} reais.`);
}



