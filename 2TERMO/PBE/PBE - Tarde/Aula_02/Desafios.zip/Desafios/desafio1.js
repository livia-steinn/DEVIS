
//////////////////////////////// DESAFIO 1 ////////////////////////////////
 
// O verificador de votação(basivo)
// Objetivo: Praticar 'if/else' simples
// Enunciado: Crie um programa que peça o nome do usuario e o ano de nascimento. O programa deve calcular a idade e dizer se ele ja tem a idade minima para votar (16 anos)

const entrada = require('readline-sync');

console.log("---VERIFICADOR DE VOTAÇÃO---");

const nome = entrada.question("Nome do usuario: ");
const anonascimento = entrada.questionInt("Ano de nascimento: ");
const idade = 2026 - anonascimento;

if (idade >= 16) {
    console.log(`\n${nome}, voce tem ${idade} anos. Voce ja pode votar!`);
} else {
    console.log(`\n Sinto muito, ${nome}. Voce tem ${idade} anos. Voce ainda nao pode votar.`);
}





