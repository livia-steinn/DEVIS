//////////////////////////////// DESAFIO 4 ////////////////////////////////

// • Desafio 4: Classificação de Atleta (Múltiplas Condições)
// • Objetivo: Praticar `else if`.
// • Enunciado: Uma escola de natação precisa classificar seus
// alunos por idade:
// • 5 a 10 anos Infantil
// • 11 a 17 anos: Juvenil
// • 18 a 60 anos: Adulto
// • Acima de 60 anos: Sênior

const entrada = require('readline-sync');

console.log("---CLASSIFICACAO DE FAIXA ETARIA DOS ATLETAS---")

const idade = entrada.questionInt("Idade do atleta: ");

if (idade >= 5 && idade <= 10) {
    console.log(`\nO atleta tem ${idade} anos. Ele entra na categoria INFANTIL.`)
} else if (idade >= 11 && idade <= 17) {
        console.log(`\nO atleta tem ${idade} anos. Ele entra na categoria JUVENIL.`)
} else if (idade >= 18 && idade <= 60) {
    console.log(`\nO atleta tem ${idade} anos. Ele entra na categoria ADULTO`)
} else if (idade>60) {
    console.log(`\n O atleta tem ${idade} anos. Ele entra na categoria SENIOR`)
}










